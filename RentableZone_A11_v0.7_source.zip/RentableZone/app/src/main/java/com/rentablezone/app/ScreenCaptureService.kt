package com.rentablezone.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.location.Geocoder
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var overlay: OverlayView? = null
    private var windowManager: WindowManager? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer: TextRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val geoExecutor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    private var busy = false
    private var lastOcrAt = 0L
    private var lastOfferAt = 0L
    private var lastDestination = ""
    private var lastAnalysis: Analysis? = null
    private var stopping = false
    private var projectionCallback: MediaProjection.Callback? = null
    private var moveReceiver: BroadcastReceiver? = null

    companion object {
        const val ACTION_MOVE_OVERLAY = "com.rentablezone.app.MOVE_OVERLAY"
        const val ACTION_APPLY_SETTINGS = "com.rentablezone.app.APPLY_SETTINGS"
        private const val CHANNEL_ID = "rentablezone_analysis"
        private const val NOTIFICATION_ID = 77
        private const val OCR_INTERVAL_MS = 650L
        private const val OFFER_TIMEOUT_MS = 1800L
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        moveReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    ACTION_MOVE_OVERLAY -> setOverlayMoveMode(intent.getBooleanExtra("enabled", false))
                    ACTION_APPLY_SETTINGS -> applyOverlaySettings()
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(ACTION_MOVE_OVERLAY)
            addAction(ACTION_APPLY_SETTINGS)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(moveReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION") registerReceiver(moveReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        val resultCode = intent.getIntExtra("resultCode", 0)
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        } ?: return START_NOT_STICKY

        startForegroundCompat()

        val manager = getSystemService(MediaProjectionManager::class.java)
        projection = manager.getMediaProjection(resultCode, data)

        if (projection == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        projection?.registerCallback(projectionCallback!!, handler)

        showOverlay()
        startCapture()
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val stopIntent = Intent(this, MainActivity::class.java).apply {
            action = MainActivity.ACTION_STOP_SERVICE
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val stopPending = PendingIntent.getActivity(
            this,
            779,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Visor Rentable activo")
            .setContentText("Analiza visualmente ofertas; no interactúa con Uber/Cabify")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "DETENER VISOR", stopPending)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Análisis RentableZone",
                NotificationManager.IMPORTANCE_LOW
            )
        )
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this) || !prefs.getBoolean("showOverlay", true)) return

        windowManager = getSystemService(WindowManager::class.java)
        overlay = OverlayView(this)
        overlay?.setBackgroundAlpha(prefs.getInt("alpha", 60))

        val metrics = resources.displayMetrics
        val widthPx = dp(prefs.getInt("overlayWidth", 315).coerceIn(220, 700))
        val maxX = (metrics.widthPixels - widthPx).coerceAtLeast(0)
        val params = WindowManager.LayoutParams(
            widthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = prefs.getInt("overlayX", 12).coerceIn(0, maxX)
        params.y = prefs.getInt("overlayY", 90).coerceIn(0, metrics.heightPixels.coerceAtLeast(1))
        overlayParams = params
        windowManager?.addView(overlay, params)
    }

    private fun setOverlayMoveMode(enabled: Boolean) {
        val view = overlay ?: return
        val params = overlayParams ?: return
        if (enabled) view.showMovePlaceholder()
        else if (lastAnalysis != null && System.currentTimeMillis() - lastOfferAt <= OFFER_TIMEOUT_MS) view.showResult(lastAnalysis!!)
        else view.hideResult()
        val metrics = resources.displayMetrics
        val flags = if (enabled) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        params.flags = flags
        view.setMoveMode(enabled) { x, y ->
            val maxX = (metrics.widthPixels - view.width).coerceAtLeast(0)
            val maxY = (metrics.heightPixels - view.height).coerceAtLeast(0)
            params.x = x.coerceIn(0, maxX)
            params.y = y.coerceIn(0, maxY)
            try { windowManager?.updateViewLayout(view, params) } catch (_: Exception) { }
            prefs.edit().putInt("overlayX", params.x).putInt("overlayY", params.y).apply()
        }
        try { windowManager?.updateViewLayout(view, params) } catch (_: Exception) { }
    }

    private fun applyOverlaySettings() {
        val old = overlay ?: return
        val wm = windowManager ?: return
        try { wm.removeView(old) } catch (_: Exception) { }
        overlay = null
        overlayParams = null
        showOverlay()
    }

    private fun startCapture() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels

        reader = ImageReader.newInstance(
            width,
            height,
            PixelFormat.RGBA_8888,
            2
        )

        virtualDisplay = projection?.createVirtualDisplay(
            "RentableZone",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface,
            null,
            handler
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            val now = System.currentTimeMillis()
            if (busy || now - lastOcrAt < OCR_INTERVAL_MS) {
                discardLatest(imageReader)
                return@setOnImageAvailableListener
            }
            lastOcrAt = now
            process(imageReader)
        }, handler)
    }

    private fun process(imageReader: ImageReader) {
        val image = try {
            imageReader.acquireLatestImage()
        } catch (_: Exception) {
            null
        } ?: return

        busy = true
        val bitmap = imageToBitmap(image)
        image.close()

        if (bitmap == null) {
            busy = false
            return
        }

        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                if (stopping) return@addOnSuccessListener

                val analysis = OfferParser.parse(result.text, prefs)
                val validOffer = isOfferAnalysis(analysis)

                if (validOffer) {
                    lastOfferAt = System.currentTimeMillis()
                    lastAnalysis = analysis
                    overlay?.showResult(analysis)
                    resolveDestinationIfNeeded(analysis)
                } else if (System.currentTimeMillis() - lastOfferAt > OFFER_TIMEOUT_MS) {
                    overlay?.hideResult()
                    lastDestination = ""
                    lastAnalysis = null
                }
            }
            .addOnFailureListener {
                if (System.currentTimeMillis() - lastOfferAt > OFFER_TIMEOUT_MS) {
                    overlay?.hideResult()
                }
            }
            .addOnCompleteListener {
                busy = false
                bitmap.recycle()
            }
    }

    private fun isOfferAnalysis(analysis: Analysis): Boolean {
        // El detalle visible de OfferParser usa "km totales" y "min totales".
        // No dependemos de etiquetas de presentación para decidir si hay una oferta.
        return !analysis.detail.contains("Oferta incompleta") &&
            analysis.detail.contains("GANANCIA BRUTA") &&
            analysis.detail.contains("km totales") &&
            analysis.detail.contains("min totales")
    }

    private fun resolveDestinationIfNeeded(analysis: Analysis) {
        val destination = analysis.destination.trim()
        if (destination.isBlank() || destination == lastDestination) return

        lastDestination = destination
        geoExecutor.execute {
            val address = try {
                val geocoder = Geocoder(this, Locale("es", "AR"))
                @Suppress("DEPRECATION")
                geocoder.getFromLocationName(destination, 1)?.firstOrNull()
            } catch (_: Exception) {
                null
            }

            if (address != null && !stopping) {
                val zoneType = ZoneStore.zoneFor(this, address.latitude, address.longitude)
                handler.post {
                    val current = lastAnalysis
                    if (current != null && current.destination == destination) {
                        overlay?.showResult(current.withZone(zoneType))
                    }
                }
            }
        }
    }

    private fun discardLatest(reader: ImageReader) {
        try {
            reader.acquireLatestImage()?.close()
        } catch (_: Exception) {
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer: ByteBuffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        return try {
            val bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)
            Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height).also {
                if (it !== bitmap) bitmap.recycle()
            }
        } catch (_: Exception) {
            null
        }
    }

    override fun onDestroy() {
        stopping = true
        moveReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) { } }
        moveReceiver = null
        handler.removeCallbacksAndMessages(null)
        virtualDisplay?.release()
        virtualDisplay = null
        reader?.close()
        reader = null
        projectionCallback?.let { callback ->
            try { projection?.unregisterCallback(callback) } catch (_: Exception) { }
        }
        projectionCallback = null
        projection?.stop()
        projection = null
        overlay?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
        recognizer.close()
        geoExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
}
