package com.rentablezone.app

/** Datos normalizados de una oferta visible. Nunca contiene acciones sobre Uber/Cabify. */
data class OfferData(
    val provider: String = "",
    val fare: Double = 0.0,
    val pickupDistanceKm: Double? = null,
    val tripDistanceKm: Double? = null,
    val pickupMinutes: Double? = null,
    val tripMinutes: Double? = null,
    val origin: String = "",
    val destination: String = "",
    val passengerTrips: Int? = null,
    val passengerRating: Double? = null,
    val cash: Boolean = false,
    val inAppPayment: Boolean = false,
    val tolls: String = "",
    val cabifyPerKmVisible: Double? = null,
    val extraInfo: List<String> = emptyList()
) {
    val totalDistanceKm: Double?
        get() = if (pickupDistanceKm != null && tripDistanceKm != null) {
            pickupDistanceKm + tripDistanceKm
        } else null

    val totalMinutes: Double?
        get() = if (pickupMinutes != null && tripMinutes != null) {
            pickupMinutes + tripMinutes
        } else null

    val hasEnoughForAnalysis: Boolean
        get() = fare > 0.0 && totalDistanceKm != null && totalMinutes != null
}
