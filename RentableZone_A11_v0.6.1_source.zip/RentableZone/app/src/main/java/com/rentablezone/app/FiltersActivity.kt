package com.rentablezone.app

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class FiltersActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filters)

        val cash = findViewById<Spinner>(R.id.spCash)
        cash.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf(
                "Efectivo: INFORMAR SOLAMENTE (no cambia el color)",
                "Efectivo: EVALUAR (amarillo)",
                "Efectivo: NO CONVIENE (rojo)"
            )
        )
        cash.setSelection(prefs.getInt("cashMode", 0).coerceIn(0, 2))

        setText(R.id.eMinKm, prefs.getFloat("minKm", 500f))
        setText(R.id.eMinHour, prefs.getFloat("minHour", 12000f))
        setText(R.id.eMaxKm, prefs.getFloat("maxKm", 30f))
        setText(R.id.eMaxMin, prefs.getFloat("maxMin", 60f))
        setText(R.id.eMinTrips, prefs.getInt("minTrips", 0))
        setText(R.id.eCostKm, prefs.getFloat("costKm", 0f))
        setText(R.id.eOverlayWidth, prefs.getInt("overlayWidth", 315))
        setText(R.id.eOverlayX, prefs.getInt("overlayX", 12))
        setText(R.id.eOverlayY, prefs.getInt("overlayY", 90))

        findViewById<SeekBar>(R.id.seekAlpha).progress = prefs.getInt("alpha", 60).coerceIn(5, 100)
        findViewById<CheckBox>(R.id.cbShowOverlay).isChecked = prefs.getBoolean("showOverlay", true)
        findViewById<CheckBox>(R.id.cbNet).isChecked = prefs.getBoolean("showNet", false)
        findViewById<CheckBox>(R.id.cbMoveOverlay).isChecked = false

        findViewById<CheckBox>(R.id.cbMoveOverlay).setOnCheckedChangeListener { _, enabled ->
            sendMoveMode(enabled)
        }

        findViewById<Button>(R.id.btnApplyOverlay).setOnClickListener {
            if (!saveSettings(showToast = false)) return@setOnClickListener
            sendApplySettings()
            toast("Cambios del visor aplicados")
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            if (!saveSettings(showToast = true)) return@setOnClickListener
            sendApplySettings()
            finish()
        }
    }

    private fun saveSettings(showToast: Boolean): Boolean {
        val minKm = value(R.id.eMinKm)
        val minHour = value(R.id.eMinHour)
        val maxKm = value(R.id.eMaxKm)
        val maxMin = value(R.id.eMaxMin)
        val minTrips = intValue(R.id.eMinTrips)
        val costKm = value(R.id.eCostKm)
        val width = intValue(R.id.eOverlayWidth).coerceIn(220, 700)
        val x = intValue(R.id.eOverlayX).coerceAtLeast(0)
        val y = intValue(R.id.eOverlayY).coerceAtLeast(0)
        val alpha = findViewById<SeekBar>(R.id.seekAlpha).progress.coerceIn(5, 100)

        if (minKm < 0 || minHour < 0 || maxKm <= 0 || maxMin <= 0 || minTrips < 0 || costKm < 0) {
            toast("Revisa los valores de los filtros")
            return false
        }

        prefs.edit()
            .putFloat("minKm", minKm.toFloat())
            .putFloat("minHour", minHour.toFloat())
            .putFloat("maxKm", maxKm.toFloat())
            .putFloat("maxMin", maxMin.toFloat())
            .putInt("minTrips", minTrips)
            .putInt("cashMode", findViewById<Spinner>(R.id.spCash).selectedItemPosition)
            .putInt("alpha", alpha)
            .putBoolean("showOverlay", findViewById<CheckBox>(R.id.cbShowOverlay).isChecked)
            .putBoolean("showNet", findViewById<CheckBox>(R.id.cbNet).isChecked)
            .putFloat("costKm", costKm.toFloat())
            .putInt("overlayWidth", width)
            .putInt("overlayX", x)
            .putInt("overlayY", y)
            .apply()

        if (showToast) toast("Filtros guardados")
        return true
    }

    private fun sendMoveMode(enabled: Boolean) {
        sendBroadcast(Intent(ScreenCaptureService.ACTION_MOVE_OVERLAY).setPackage(packageName).putExtra("enabled", enabled))
    }

    private fun sendApplySettings() {
        sendBroadcast(Intent(ScreenCaptureService.ACTION_APPLY_SETTINGS).setPackage(packageName))
    }

    private fun setText(id: Int, value: Number) {
        findViewById<EditText>(id).setText(value.toString())
    }

    private fun value(id: Int): Double =
        findViewById<EditText>(id).text.toString().trim().replace(',', '.').toDoubleOrNull() ?: 0.0

    private fun intValue(id: Int): Int =
        findViewById<EditText>(id).text.toString().trim().toIntOrNull() ?: 0

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
