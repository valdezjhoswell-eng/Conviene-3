package com.rentablezone.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

class OverlayView(context: Context) : LinearLayout(context) {
    private val title = TextView(context)
    private val detail = TextView(context)
    private var moveMode = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var moveCallback: ((Int, Int) -> Unit)? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.START
        setPadding(16, 10, 16, 10)
        val bg = GradientDrawable().apply {
            setColor(Color.argb(210, 20, 30, 45))
            cornerRadius = 22f
            setStroke(1, Color.argb(90, 255, 255, 255))
        }
        background = bg
        title.setTextColor(Color.WHITE)
        title.textSize = 17f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        detail.setTextColor(Color.WHITE)
        detail.textSize = 13.5f
        detail.setLineSpacing(0f, 1.05f)
        addView(title, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(detail, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    fun showResult(result: Analysis) {
        visibility = VISIBLE
        title.text = result.label
        title.setTextColor(result.color)
        detail.text = result.detail
    }

    fun hideResult() {
        visibility = INVISIBLE
    }

    fun showMovePlaceholder() {
        visibility = VISIBLE
        title.text = "VISOR RENTABLE — MOVER"
        title.setTextColor(Color.WHITE)
        detail.text = "Arrastra este cuadro por toda la pantalla.\nDesactiva Modo MOVER al terminar."
    }

    fun setBackgroundAlpha(alphaPercent: Int) {
        val a = (255 * alphaPercent.coerceIn(5, 100) / 100f).toInt()
        background?.alpha = a
    }

    fun setMoveMode(enabled: Boolean, onMoved: (x: Int, y: Int) -> Unit) {
        moveMode = enabled
        moveCallback = onMoved
        isClickable = enabled
        isFocusable = enabled
        if (enabled) {
            setOnTouchListener { _, event ->
                if (!moveMode) return@setOnTouchListener false
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX
                        downRawY = event.rawY
                        val lp = layoutParams as? android.view.WindowManager.LayoutParams
                        startX = lp?.x ?: 0
                        startY = lp?.y ?: 0
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downRawX
                        val dy = event.rawY - downRawY
                        val x = (startX + dx).roundToInt()
                        val y = (startY + dy).roundToInt()
                        moveCallback?.invoke(x, y)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                    else -> false
                }
            }
        } else {
            setOnTouchListener(null)
        }
    }
}

data class Analysis(
    val label: String,
    val detail: String,
    val color: Int,
    val destination: String = ""
) {
    fun withZone(type: Int?): Analysis {
        val suffix = when (type) {
            2 -> "\n🔴 ZONA PELIGROSA"
            1 -> "\n🟡 ZONA DE PRECAUCIÓN"
            0 -> "\n🟢 ZONA PERMITIDA"
            else -> "\n⚪ ZONA NO DETERMINADA"
        }
        return copy(detail = detail + suffix)
    }
}
