package com.rentablezone.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.media.projection.MediaProjectionManager

class MainActivity : AppCompatActivity() {
    companion object {
        private const val CAPTURE_REQUEST = 1001
        const val ACTION_STOP_SERVICE = "com.rentablezone.app.STOP_SERVICE"
    }

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopService(Intent(this, ScreenCaptureService::class.java))
        }
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.txtStatus)

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } else {
                toast("Permiso de superposición ya concedido")
            }
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener { startCapture() }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, ScreenCaptureService::class.java))
            status.text = "Estado: detenido"
        }

        findViewById<Button>(R.id.btnZones).setOnClickListener {
            startActivity(Intent(this, ZonesActivity::class.java))
        }

        findViewById<Button>(R.id.btnFilters).setOnClickListener {
            startActivity(Intent(this, FiltersActivity::class.java))
        }
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Primero autoriza la superposición")
            return
        }

        val manager = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(
            manager.createScreenCaptureIntent(),
            CAPTURE_REQUEST
        )
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopService(Intent(this, ScreenCaptureService::class.java))
            status.text = "Estado: detenido"
        }
    }

    @Deprecated("Compatibilidad con Android Activity result existente en este proyecto")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != CAPTURE_REQUEST) return

        if (resultCode != Activity.RESULT_OK || data == null) {
            status.text = "Estado: autorización de captura cancelada"
            return
        }

        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra("resultCode", resultCode)
            putExtra("data", data)
        }

        startForegroundService(serviceIntent)
        status.text = "Estado: visor activo"
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
