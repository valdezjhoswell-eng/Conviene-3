package com.rentablezone.app

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import android.location.Geocoder
import java.util.Locale
import java.util.concurrent.Executors
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon

class ZonesActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private lateinit var pointStatus: TextView
    private lateinit var spinner: Spinner
    private val points = mutableListOf<GeoPoint>()
    private val pointMarkers = mutableListOf<Marker>()
    private val savedPolygons = mutableListOf<Polygon>()
    private var currentPolygon: Polygon? = null
    private val zones = mutableListOf<SavedZone>()
    private val geocoderExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        setContentView(R.layout.activity_zones)

        zones.addAll(ZoneStore.load(this))
        map = findViewById(R.id.map)
        pointStatus = findViewById(R.id.txtPoints)
        spinner = findViewById(R.id.spZone)

        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.controller.setZoom(11.5)
        map.controller.setCenter(GeoPoint(-34.6037, -58.3816))

        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("🟢 VERDE — permitida", "🟡 AMARILLA — precaución", "🔴 ROJA — peligrosa")
        )
        spinner.setSelection(0)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                redrawCurrent()
            }
        }

        val mapEventsReceiver = object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                addPoint(p)
                return true
            }

            override fun longPressHelper(p: GeoPoint): Boolean = false
        }
        map.overlays.add(MapEventsOverlay(mapEventsReceiver))

        findViewById<Button>(R.id.btnSave).setOnClickListener { saveCurrentZone() }
        findViewById<Button>(R.id.btnSearchLocation).setOnClickListener { searchLocation() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearCurrentZone() }

        drawSavedZones()
        updatePointStatus()
    }


    private fun searchLocation() {
        val query = findViewById<EditText>(R.id.eLocation).text.toString().trim()
        if (query.isBlank()) {
            toast("Escribe una localidad, barrio o dirección")
            return
        }
        toast("Buscando localidad…")
        geocoderExecutor.execute {
            val results = try {
                val geocoder = Geocoder(this, Locale("es", "AR"))
                @Suppress("DEPRECATION")
                geocoder.getFromLocationName(query, 8).orEmpty()
            } catch (_: Exception) {
                emptyList()
            }
            mainHandler.post {
                if (results.isEmpty()) {
                    toast("No encontré esa localidad. Prueba con localidad + provincia, por ejemplo: Morón, Buenos Aires")
                    return@post
                }
                val labels = results.map { address ->
                    buildString {
                        append(address.featureName ?: query)
                        if (!address.locality.isNullOrBlank()) append(" — ${address.locality}")
                        if (!address.adminArea.isNullOrBlank()) append(" — ${address.adminArea}")
                    }
                }.distinct()
                AlertDialog.Builder(this)
                    .setTitle("Selecciona la localidad o resultado")
                    .setItems(labels.toTypedArray()) { _, which ->
                        val address = results[which]
                        map.controller.setCenter(GeoPoint(address.latitude, address.longitude))
                        map.controller.setZoom(14.0)
                        toast("Mapa centrado en ${labels[which]}")
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
    }

    private fun addPoint(point: GeoPoint) {
        points += point
        val marker = Marker(map).apply {
            position = point
            title = "Punto ${points.size}"
            setTextIcon(points.size.toString())
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        }
        pointMarkers += marker
        map.overlays.add(marker)
        redrawCurrent()
        updatePointStatus()
        map.invalidate()
    }

    private fun saveCurrentZone() {
        if (points.size < 3) {
            toast("Marca al menos 3 puntos sobre el mapa")
            return
        }
        zones += SavedZone(spinner.selectedItemPosition, points.toList())
        ZoneStore.save(this, zones)
        toast("Zona ${zoneName(spinner.selectedItemPosition)} guardada")
        clearCurrentZone()
        drawSavedZones()
    }

    private fun clearCurrentZone() {
        points.clear()
        pointMarkers.forEach { map.overlays.remove(it) }
        pointMarkers.clear()
        currentPolygon?.let { map.overlays.remove(it) }
        currentPolygon = null
        updatePointStatus()
        map.invalidate()
    }

    private fun redrawCurrent() {
        currentPolygon?.let { map.overlays.remove(it) }
        currentPolygon = null
        if (points.size < 3) {
            map.invalidate()
            return
        }
        val polygon = Polygon(map).apply {
            points.forEach { addPoint(it) }
            fillColor = Color.argb(65, Color.red(zoneColor(spinner.selectedItemPosition)), Color.green(zoneColor(spinner.selectedItemPosition)), Color.blue(zoneColor(spinner.selectedItemPosition)))
            strokeColor = zoneColor(spinner.selectedItemPosition)
            strokeWidth = 5f
        }
        currentPolygon = polygon
        map.overlays.add(polygon)
        map.invalidate()
    }

    private fun drawSavedZones() {
        savedPolygons.forEach { map.overlays.remove(it) }
        savedPolygons.clear()
        zones.forEach { zone ->
            if (zone.points.size >= 3) {
                val polygon = Polygon(map).apply {
                    zone.points.forEach { addPoint(it) }
                    val c = zoneColor(zone.type)
                    fillColor = Color.argb(60, Color.red(c), Color.green(c), Color.blue(c))
                    strokeColor = c
                    strokeWidth = 5f
                    title = zoneName(zone.type)
                }
                savedPolygons += polygon
                map.overlays.add(polygon)
            }
        }
        map.invalidate()
    }

    private fun zoneColor(type: Int): Int = when (type) {
        0 -> Color.rgb(30, 170, 90)
        1 -> Color.rgb(220, 160, 20)
        else -> Color.rgb(210, 55, 70)
    }

    private fun zoneName(type: Int): String = when (type) {
        0 -> "VERDE — permitida"
        1 -> "AMARILLA — precaución"
        else -> "ROJA — peligrosa"
    }

    private fun updatePointStatus() {
        pointStatus.text = "Puntos de la zona actual: ${points.size}  •  Necesitas 3 o más para guardar"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { map.onPause(); super.onPause() }
    override fun onDestroy() { geocoderExecutor.shutdownNow(); map.onDetach(); super.onDestroy() }
}
