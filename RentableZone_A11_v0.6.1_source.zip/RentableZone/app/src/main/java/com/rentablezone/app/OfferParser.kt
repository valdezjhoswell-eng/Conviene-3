package com.rentablezone.app

import android.content.SharedPreferences
import android.graphics.Color
import java.util.Locale

object OfferParser {
    private val money = Regex("(?:ARS|\$)\\s*([0-9][0-9.,]*)|([0-9][0-9.,]*)\\s*ARS", RegexOption.IGNORE_CASE)
    private val km = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*km\\b", RegexOption.IGNORE_CASE)
    private val meters = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*m\\b", RegexOption.IGNORE_CASE)
    private val min = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*min\\b", RegexOption.IGNORE_CASE)
    private val trips = Regex("([0-9]+)\\s*(?:viajes|viaje)\\b", RegexOption.IGNORE_CASE)
    private val rating = Regex("(?:calificaci[oó]n|valoraci[oó]n|rating|⭐)\\s*[:]?\\s*([0-5](?:[.,][0-9]+)?)", RegexOption.IGNORE_CASE)
    private val cabifyPerKm = Regex("\\$\\s*/?\\s*km\\s*([0-9][0-9.,]*)|([0-9][0-9.,]*)\\s*\\$/?km", RegexOption.IGNORE_CASE)

    fun parse(text: String, p: SharedPreferences): Analysis {
        val data = parseData(text)
        if (!data.hasEnoughForAnalysis) {
            return Analysis(
                label = "🟡 EVALUAR",
                detail = buildDetail(data, null, null, listOf("Oferta incompleta o no detectada"), p),
                color = Color.rgb(255, 205, 70),
                destination = data.destination
            )
        }

        val distance = data.totalDistanceKm!!
        val minutes = data.totalMinutes!!
        val perKm = data.fare / distance
        val perHour = data.fare / (minutes / 60.0)

        val minKm = p.getFloat("minKm", 500f).toDouble()
        val minHour = p.getFloat("minHour", 12000f).toDouble()
        val maxKm = p.getFloat("maxKm", 30f).toDouble()
        val maxMin = p.getFloat("maxMin", 60f).toDouble()
        val minTrips = p.getInt("minTrips", 0)
        val cashMode = p.getInt("cashMode", 0)

        val hardReasons = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        if (perKm < minKm) hardReasons += "$/km bajo"
        if (perHour < minHour) hardReasons += "$/hora baja"
        if (distance > maxKm) hardReasons += "distancia máxima superada"
        if (minutes > maxMin) hardReasons += "tiempo máximo superado"
        if (data.passengerTrips != null && data.passengerTrips < minTrips) hardReasons += "pocos viajes del pasajero"

        if (data.cash) {
            when (cashMode) {
                1 -> warnings += "💵 EFECTIVO: REVISAR"
                2 -> hardReasons += "💵 EFECTIVO: NO CONVIENE"
                else -> warnings += "💵 EFECTIVO"
            }
        } else if (data.provider == "CABIFY" && data.inAppPayment) {
            warnings += "💳 EN APP"
        }

        val label: String
        val color: Int
        when {
            hardReasons.isNotEmpty() -> {
                label = "🔴 NO CONVIENE"
                color = Color.rgb(255, 100, 100)
            }
            warnings.isNotEmpty() -> {
                label = "🟡 EVALUAR"
                color = Color.rgb(255, 205, 70)
            }
            else -> {
                label = "🟢 CONVIENE"
                color = Color.rgb(90, 240, 150)
            }
        }

        val reasonLines = (hardReasons + warnings).take(3)
        return Analysis(
            label = label,
            detail = buildDetail(data, perKm, perHour, reasonLines, p),
            color = color,
            destination = data.destination
        )
    }

    fun parseData(text: String): OfferData {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val joined = lines.joinToString(" ")
        val low = joined.lowercase(Locale.getDefault())
        val provider = when {
            low.contains("cabify") -> "CABIFY"
            low.contains("uber") -> "UBER"
            else -> ""
        }

        val amounts = money.findAll(joined)
            .mapNotNull { m -> parseNum(m.groupValues.firstOrNull { it.isNotBlank() }) }
            .filter { it > 0 }
            .toList()
        val fare = amounts.filter { it >= 1000 }.maxOrNull() ?: amounts.maxOrNull() ?: 0.0

        val distanceCandidates = extractDistances(lines)
        val timeCandidates = min.findAll(joined).mapNotNull { parseNum(it.groupValues[1]) }.filter { it > 0 }.toList()

        val pickupDistance = findLabeledDistance(lines, listOf("recogida", "hasta el pasajero", "hasta recoger", "pickup"))
            ?: distanceCandidates.getOrNull(0)
        val tripDistance = findLabeledDistance(lines, listOf("viaje", "con pasajero", "destino", "hasta destino"))
            ?: distanceCandidates.getOrNull(1)

        val pickupMinutes = findLabeledMinutes(lines, listOf("recogida", "hasta el pasajero", "hasta recoger", "pickup"))
            ?: timeCandidates.getOrNull(0)
        val tripMinutes = findLabeledMinutes(lines, listOf("viaje", "con pasajero", "destino", "hasta destino"))
            ?: timeCandidates.getOrNull(1)

        val destination = extractDestination(lines, provider)
        val origin = extractOrigin(lines, destination)
        val tripCount = trips.find(joined)?.groupValues?.get(1)?.toIntOrNull()
        val passengerRating = rating.find(joined)?.groupValues?.get(1)?.let(::parseNum)
        val cash = low.contains("efectivo") || low.contains("cash")
        val inApp = low.contains("en app") || low.contains("app") && provider == "CABIFY"
        val tolls = lines.firstOrNull { l ->
            val s = l.lowercase(Locale.getDefault())
            s.contains("peaje") || s.contains("peajes") || s.contains("toll")
        }.orEmpty()
        val cabifyKmVisible = cabifyPerKm.find(joined)?.let { m ->
            parseNum(m.groupValues.firstOrNull { it.isNotBlank() })
        }

        val extra = lines.filter { line ->
            val s = line.lowercase(Locale.getDefault())
            s.contains("peaje") || s.contains("efectivo") || s.contains("en app") || s.contains("app")
        }.distinct().take(4)

        return OfferData(
            provider = provider,
            fare = fare,
            pickupDistanceKm = pickupDistance,
            tripDistanceKm = tripDistance,
            pickupMinutes = pickupMinutes,
            tripMinutes = tripMinutes,
            origin = origin,
            destination = destination,
            passengerTrips = tripCount,
            passengerRating = passengerRating,
            cash = provider == "CABIFY" && cash,
            inAppPayment = provider == "CABIFY" && inApp,
            tolls = tolls,
            cabifyPerKmVisible = cabifyKmVisible,
            extraInfo = extra
        )
    }

    private fun extractDistances(lines: List<String>): List<Double> {
        val result = mutableListOf<Double>()
        for (line in lines) {
            km.findAll(line).forEach { parseNum(it.groupValues[1])?.let(result::add) }
            meters.findAll(line).forEach { parseNum(it.groupValues[1])?.let { value -> result += value / 1000.0 } }
        }
        return result
    }

    private fun findLabeledDistance(lines: List<String>, labels: List<String>): Double? {
        for (line in lines) {
            val low = line.lowercase(Locale.getDefault())
            if (labels.any { low.contains(it) }) {
                km.find(line)?.let { return parseNum(it.groupValues[1]) }
                meters.find(line)?.let { match -> parseNum(match.groupValues[1])?.let { value -> return value / 1000.0 } }
            }
        }
        return null
    }

    private fun findLabeledMinutes(lines: List<String>, labels: List<String>): Double? {
        for (line in lines) {
            val low = line.lowercase(Locale.getDefault())
            if (labels.any { low.contains(it) }) {
                min.find(line)?.let { return parseNum(it.groupValues[1]) }
            }
        }
        return null
    }

    private fun extractDestination(lines: List<String>, provider: String): String {
        val destinationLabels = listOf("destino", "hasta", "llevar a", "dirección de destino", "direccion de destino")
        for (i in lines.indices) {
            val low = lines[i].lowercase(Locale.getDefault())
            if (destinationLabels.any { low.contains(it) }) {
                val same = lines[i].substringAfter(":", "").trim()
                if (same.length >= 3) return same
                lines.getOrNull(i + 1)?.let { if (isAddressLike(it)) return it }
            }
        }
        for (i in lines.indices) {
            val low = lines[i].lowercase(Locale.getDefault())
            if (low.contains("viaje") && i + 1 < lines.size && isAddressLike(lines[i + 1])) return lines[i + 1]
        }
        return if (provider.isNotBlank()) lines.asReversed().firstOrNull(::isAddressLike).orEmpty() else ""
    }

    private fun extractOrigin(lines: List<String>, destination: String): String {
        for (i in lines.indices) {
            val low = lines[i].lowercase(Locale.getDefault())
            if (low.contains("origen") || low.contains("recogida") || low.contains("pickup")) {
                val same = lines[i].substringAfter(":", "").trim()
                if (same.length >= 3 && same != destination) return same
                lines.getOrNull(i + 1)?.let { if (isAddressLike(it) && it != destination) return it }
            }
        }
        return ""
    }

    private fun isAddressLike(s: String): Boolean {
        val x = s.trim()
        if (x.length < 4 || x.length > 120) return false
        if (Regex("^[\\d.,$€]+$").matches(x)) return false
        return !Regex("^(uber|cabify|aceptar|rechazar|cancelar|efectivo|en app)$", RegexOption.IGNORE_CASE).matches(x)
    }

    private fun buildDetail(data: OfferData, perKm: Double?, perHour: Double?, reasons: List<String>, p: SharedPreferences): String = buildString {
        if (data.fare > 0) {
            append("💰 GANANCIA BRUTA: ${fmt(data.fare)} ARS\n")
            if (p.getBoolean("showNet", false)) {
                val costKm = p.getFloat("costKm", 0f).toDouble()
                val total = data.totalDistanceKm ?: 0.0
                val net = data.fare - costKm * total
                append("💰 GANANCIA NETA: ${fmt(net)} ARS\n")
            }
        }
        data.totalDistanceKm?.let { total -> append("📏 DISTANCIA TOTAL REAL: ${fmt1(total)} km\n") }
        if (perKm != null) append("💵 GANANCIA: ${fmt(perKm)}/km\n")
        if (perHour != null) append("⏱️ GANANCIA: ${fmt(perHour)}/hora\n")
        data.totalMinutes?.let { total -> append("⌛ TIEMPO TOTAL REAL: ${fmt1(total)} min\n") }
        if (data.pickupDistanceKm != null || data.tripDistanceKm != null) {
            append("↳ Recogida ${fmt1(data.pickupDistanceKm ?: 0.0)} km + viaje ${fmt1(data.tripDistanceKm ?: 0.0)} km\n")
        }
        if (data.pickupMinutes != null || data.tripMinutes != null) {
            append("↳ ${fmt1(data.pickupMinutes ?: 0.0)} min + ${fmt1(data.tripMinutes ?: 0.0)} min\n")
        }
        if (data.passengerTrips != null) append("👤 ${data.passengerTrips} viajes") else append("👤 Viajes no detectados")
        if (data.passengerRating != null) append(" · ⭐ ${fmt1(data.passengerRating)}")
        append("\n")
        if (data.cash) append("💵 EFECTIVO\n")
        if (data.inAppPayment) append("💳 EN APP\n")
        if (data.tolls.isNotBlank()) append("🛣️ ${data.tolls}\n")
        if (data.cabifyPerKmVisible != null) append("Cabify $/km visible: ${fmt(data.cabifyPerKmVisible)}\n")
        if (reasons.isNotEmpty()) append(reasons.joinToString("\n"))
        if (data.provider.isNotBlank()) append(if (reasons.isNotEmpty()) "\n" else "").append(data.provider)
        if (data.origin.isNotBlank()) append("\n📍 Origen: ${data.origin}")
        if (data.destination.isNotBlank()) append("\n🏁 Destino: ${data.destination}")
    }

    private fun parseNum(s: String?): Double? {
        if (s == null) return null
        val x = s.trim()
        if (x.isBlank()) return null
        return when {
            x.contains('.') && x.contains(',') -> x.replace(".", "").replace(',', '.').toDoubleOrNull()
            x.contains('.') && x.substringAfter('.').length == 3 -> x.replace(".", "").toDoubleOrNull()
            x.contains(',') && x.substringAfter(',').length == 3 -> x.replace(",", "").toDoubleOrNull()
            else -> x.replace(',', '.').toDoubleOrNull()
        }
    }

    private fun fmt(v: Double) = String.format(Locale.US, "%,.0f", v).replace(',', '.')
    private fun fmt1(v: Double) = String.format(Locale.US, "%.1f", v).replace('.', ',')
}
