# Configuración rápida — Galaxy Tab A11

1. Abrir la carpeta del proyecto en Android Studio.
2. Configurar `MAPS_API_KEY` si se quiere utilizar el mapa.
3. Sincronizar Gradle.
4. Compilar el APK de debug.
5. Instalar en la Galaxy Tab A11.
6. Abrir RentableZone y conceder "Mostrar sobre otras aplicaciones".
7. Pulsar "Iniciar visor" y aceptar el diálogo de captura de pantalla de Android.

## Importante

RentableZone solamente observa y analiza visualmente. El overlay utiliza `FLAG_NOT_TOUCHABLE`; no puede utilizarse para pulsar controles de Uber/Cabify.

La distancia y el tiempo utilizados por el análisis son exclusivamente:

`recogida + viaje`

No existe cálculo de regreso.
